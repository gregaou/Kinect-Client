#ifndef BEAMANGLEMODE_H
#define BEAMANGLEMODE_H

typedef enum
{
	Automatic,
	Adaptative,
	Manual
} BeamAngleMode;

#endif
