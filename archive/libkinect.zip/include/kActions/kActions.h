#ifndef KACTIONS_H
#define KACTIONS_H

#include "kAction.h"
#include "kMessageAction.h"
#include "kKinectSensorCollectionStatusChangedAction.h"
#include "kKinectSensorColorFrameReadyAction.h"
#include "kKinectSensorDepthFrameReadyAction.h"
#include "kKinectSensorSkeletonFrameReadyAction.h"
#include "kKinectSensorAudioDataReadyAction.h"
#include "kKinectAudioSourceBeamAngleChangedAction.h"
#include "kKinectAudioSourceSoundSourceAngleChangedAction.h"

#endif
