#ifndef DEPTHRANGE_H
#define DEPTHRANGE_H

#ifndef Default
#define Default 0
#endif

typedef enum
{
	Near = 1
} DepthRange;

#endif
