#ifndef BYTE_H
#define BYTE_H

typedef unsigned char byte;

#endif
