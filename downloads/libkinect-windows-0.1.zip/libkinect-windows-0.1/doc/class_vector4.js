var class_vector4 =
[
    [ "Vector4", "class_vector4.html#a8c0dbcc29bd3023f1ec32bd93023a209", null ],
    [ "Vector4", "class_vector4.html#a6995caf87d59c9c8e9a565648e43b64c", null ],
    [ "unserialize", "class_vector4.html#a3fe98d9342ebd21bc46f6c91d45d8980", null ],
    [ "serializedSize", "class_vector4.html#aafa540459c1b29bc1d51cc641300bdd3", null ],
    [ "getX", "class_vector4.html#a0d704b892717a8c5c7360956c9b7fe1d", null ],
    [ "setX", "class_vector4.html#ae4ce17d214fdb71b1c00d42dc1f54b1b", null ],
    [ "getY", "class_vector4.html#aa432c84cd0c29b8aeb2204a5ab6fec39", null ],
    [ "setY", "class_vector4.html#a802a9f7987d6589b64dfea11d062a6e9", null ],
    [ "getZ", "class_vector4.html#a4760248a7756e406b6e91dc6efc5ffb8", null ],
    [ "setZ", "class_vector4.html#a64787391d1a10a6c88e9cf45ad79585b", null ],
    [ "getW", "class_vector4.html#af5ddabb33678895262638ab66ea7afe4", null ],
    [ "setW", "class_vector4.html#ab07082d6f41e5dff3eb1c225a28a4ab0", null ],
    [ "equals", "class_vector4.html#a5769ec402880ed9ac22c38abbc245371", null ],
    [ "_x", "class_vector4.html#a94c2bc2bf757799c2c4d9210da3b741c", null ],
    [ "_y", "class_vector4.html#a8fb3e80b19fc3d0613de896ef3bcf5d0", null ],
    [ "_z", "class_vector4.html#a9e3eb8e08831c1b6a61d046b04dfc906", null ],
    [ "_w", "class_vector4.html#ac3285ce9bb8bf3233c38e2c5d56d7c73", null ]
];