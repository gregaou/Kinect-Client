var class_k_object =
[
    [ "KObject", "class_k_object.html#a6683116c693e9a37c0ef00652353cdee", null ],
    [ "~KObject", "class_k_object.html#a44b9ce312ca5ba79132f5b75f2ff0744", null ],
    [ "splitString", "class_k_object.html#a9e6f91f3ad4ce80bf3baf15a566ced35", null ],
    [ "sensorId", "class_k_object.html#a72b28971b996b8a2b70d567c295e5b34", null ],
    [ "checkRet", "class_k_object.html#af1ffc23fe4ba7bcb3c4ad7dbac6b26a0", null ],
    [ "checkRet", "class_k_object.html#a8814d409199a7e8fdb29a72c6d54e7b8", null ],
    [ "buildQuery", "class_k_object.html#a9f070f2c33d432edd500491e9cfa2893", null ],
    [ "buildQuery", "class_k_object.html#a54696f077757fe0162e722e37c52e2d5", null ],
    [ "processQuery", "class_k_object.html#acafab7a531af4296be8b7f534937f4a7", null ],
    [ "lastMessage", "class_k_object.html#ab44f2faad5124fc17bd044751b776bd6", null ],
    [ "lastData", "class_k_object.html#a4e32773ee8578142583397e6681b1e9a", null ],
    [ "getQuery", "class_k_object.html#a38c4120b3e56d3076f2838968a1f20f1", null ],
    [ "setQuery", "class_k_object.html#a4de0b14b191b6e9b55384a726b37bcb3", null ],
    [ "_className", "class_k_object.html#ac841878ebba61eaab2a7d5f1ed2e4bf3", null ],
    [ "_sensorId", "class_k_object.html#adde27b10fdb36266f22f67922b3ad392", null ],
    [ "_client", "class_k_object.html#ad4516bcd3dc09f51531fcca9d701eb28", null ]
];