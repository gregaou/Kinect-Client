var class_beam_angle_changed_event_args =
[
    [ "BeamAngleChangedEventArgs", "class_beam_angle_changed_event_args.html#a228c5bd920fd3b04f3a62489e50d750e", null ],
    [ "getAngle", "class_beam_angle_changed_event_args.html#aebcca10b189651be5146b18eed22bfd5", null ],
    [ "setAngle", "class_beam_angle_changed_event_args.html#a48a006b9de2fcc25e10e42cd2ed605fe", null ],
    [ "_angle", "class_beam_angle_changed_event_args.html#af6be014f5d4ba1bc50572cf12f084bb2", null ]
];