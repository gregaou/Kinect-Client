var class_k_tcp_socket =
[
    [ "KTcpSocket", "class_k_tcp_socket.html#a045e2a34c997d5e28e1da39370ec9860", null ],
    [ "~KTcpSocket", "class_k_tcp_socket.html#a1cf2b5837574dfc7788e07f43553143d", null ],
    [ "end", "class_k_tcp_socket.html#a0b9796287366426b4d94eafd2abfdb2b", null ],
    [ "writeBuffer", "class_k_tcp_socket.html#ac630d99406bee2b5c4c217c9e85c1614", null ],
    [ "readBuffer", "class_k_tcp_socket.html#a3610bd7e5426abcbe376d2b093d63370", null ],
    [ "buildAddr", "class_k_tcp_socket.html#a904a4f485d8e276682774148fea74ccb", null ],
    [ "connectToHost", "class_k_tcp_socket.html#a818657a697da38ee9121d16455a14d7d", null ],
    [ "_sock", "class_k_tcp_socket.html#a3c8d943560cd0c81a0ccbb135cbd25fe", null ],
    [ "_sin", "class_k_tcp_socket.html#ac68dd05eb7c190998e4ec2b69b0a7b4e", null ],
    [ "_port", "class_k_tcp_socket.html#a5492c4ec63bfaf00541ac25e1ee4493e", null ],
    [ "_host", "class_k_tcp_socket.html#a882f1f3a38a02859ee16d8a942c49125", null ]
];