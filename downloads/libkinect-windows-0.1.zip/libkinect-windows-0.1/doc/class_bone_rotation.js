var class_bone_rotation =
[
    [ "BoneRotation", "class_bone_rotation.html#a676f1bad3ae4b4f65f58ed411d508935", null ],
    [ "BoneRotation", "class_bone_rotation.html#aa9aa2b04d5be69e1a2953d57a07d2a39", null ],
    [ "unserialize", "class_bone_rotation.html#a90aafb3e031ef86d325cb879e12b95b8", null ],
    [ "serializedSize", "class_bone_rotation.html#a9b1a19237d710092463c2aadeb54fed2", null ],
    [ "getMatrix", "class_bone_rotation.html#a511c75443d388ec75d609ab75b3580b3", null ],
    [ "setMatrix", "class_bone_rotation.html#a61d37984c33366cb8b34cf9c2232a8b6", null ],
    [ "getQuaternion", "class_bone_rotation.html#a6b540c5081efbe691260495517f0abba", null ],
    [ "setQuaternion", "class_bone_rotation.html#a349413b470bf55a33c43875f181a0e61", null ],
    [ "_matrix", "class_bone_rotation.html#a7c678ac5001e52800d47f18b75c4f483", null ],
    [ "_quaternion", "class_bone_rotation.html#a2aa48c611ebd8037321e88d566b015fa", null ]
];