var class_depth_image_point =
[
    [ "DepthImagePoint", "class_depth_image_point.html#a39950bd296ddaaf2d339af3c3ec80047", null ],
    [ "getX", "class_depth_image_point.html#a74cd6795b7a3b9a81fc909527057e43a", null ],
    [ "setX", "class_depth_image_point.html#a3b511d1d2e194ada3bd0751885cbf856", null ],
    [ "getY", "class_depth_image_point.html#a4d856c47e702863994f63541cd4ee892", null ],
    [ "setY", "class_depth_image_point.html#ac4eefdb22062c9bedbdfba660f0b2719", null ],
    [ "getDepth", "class_depth_image_point.html#a43790a128d095f39790642f98dd14ed5", null ],
    [ "getPlayerIndex", "class_depth_image_point.html#ab0c3b41232d517b71b28eb961bd138fa", null ],
    [ "equals", "class_depth_image_point.html#a3e9796247d1469588c5517c142d6190c", null ],
    [ "_depth", "class_depth_image_point.html#a39a7ca1acf3499cc9c6f7070920a3fe9", null ],
    [ "_playerIndex", "class_depth_image_point.html#a4f30fb52c2fa0eeecb5f507f4297daae", null ],
    [ "_x", "class_depth_image_point.html#a55fcbf59aba95d30a1692f6d2d49b982", null ],
    [ "_y", "class_depth_image_point.html#ad0765e4ad98717d1c0041bb7a2e31a7e", null ]
];