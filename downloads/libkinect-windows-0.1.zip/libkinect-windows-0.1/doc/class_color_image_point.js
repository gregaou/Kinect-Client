var class_color_image_point =
[
    [ "ColorImagePoint", "class_color_image_point.html#af165b5f45b5c05e3d720376a0011f7c3", null ],
    [ "getX", "class_color_image_point.html#a1736c098649722642c4b627202c896f8", null ],
    [ "setX", "class_color_image_point.html#a0a7b98e6076a72d52f7fb29cf51a1633", null ],
    [ "getY", "class_color_image_point.html#ae07402fd2f292ccd4acb3b767fb82f09", null ],
    [ "setY", "class_color_image_point.html#a3524b7e61926b0150f89d05246d9b414", null ],
    [ "equals", "class_color_image_point.html#a60b0e8b3b9fce04835712a879c99ca2f", null ],
    [ "_x", "class_color_image_point.html#a9d561ee08837e295d0da7c5dcdf92d89", null ],
    [ "_y", "class_color_image_point.html#a3fc1969655cb7710fe088e061faec376", null ]
];