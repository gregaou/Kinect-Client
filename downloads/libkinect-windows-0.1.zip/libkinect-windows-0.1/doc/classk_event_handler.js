var classk_event_handler =
[
    [ "kEventHandler", "classk_event_handler.html#a9afe98e5b84d6567f27e8a2ffbe3e298", null ],
    [ "operator=", "classk_event_handler.html#ad82de434d0e11c56d7931878046c0702", null ],
    [ "operator()", "classk_event_handler.html#a36154ef43b611250e42bb6f3ceee1a56", null ],
    [ "operator!", "classk_event_handler.html#a71602ccfa5a319cc26c865f30130c4e8", null ],
    [ "_handler", "classk_event_handler.html#a31990108c0c183f738ef037777e511ff", null ]
];