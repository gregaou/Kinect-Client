var class_kinect_sensor_collection =
[
    [ "~KinectSensorCollection", "class_kinect_sensor_collection.html#a0f6280602986ffe061ec80b0888bbca9", null ],
    [ "instance", "class_kinect_sensor_collection.html#a2f80ad52f4b2ffeb08ac0f4340ee0549", null ],
    [ "deleteInstance", "class_kinect_sensor_collection.html#a66e802b4e51ddd75454defd6261034a5", null ],
    [ "Count", "class_kinect_sensor_collection.html#a63b366b1e45339c289656373a73424b2", null ],
    [ "size", "class_kinect_sensor_collection.html#a44ce2747247e1eaa12e2b49cb5e05e42", null ],
    [ "operator[]", "class_kinect_sensor_collection.html#a54dbf9e02d92758e69c8decfb4d46de4", null ],
    [ "statusChangedCb", "class_kinect_sensor_collection.html#a6d72ed16cd8e58408d649d5b771f6765", null ],
    [ "setStatusChangeCb", "class_kinect_sensor_collection.html#a13d3f7d3a75174708b767fd2fbd1c98d", null ],
    [ "_sensors", "class_kinect_sensor_collection.html#aa4be9615110dcd193e7c2c7a766cbb86", null ],
    [ "_statusChangedCb", "class_kinect_sensor_collection.html#a865bf1948bce09ba68203f59f1f6b089", null ]
];