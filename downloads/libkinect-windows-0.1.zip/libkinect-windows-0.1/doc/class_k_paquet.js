var class_k_paquet =
[
    [ "KPaquet", "class_k_paquet.html#aa047eb1c546cbb413b6eedfae146cfde", null ],
    [ "~KPaquet", "class_k_paquet.html#a45e65a36b75f70ce5d9b386957784a2e", null ],
    [ "bodySize", "class_k_paquet.html#a945636ea48b747cbb824cb24539b9bd6", null ],
    [ "totalSize", "class_k_paquet.html#ad04daf863244252861f9f53dc0056f4e", null ],
    [ "timestamp", "class_k_paquet.html#ad497c646580ab3488cfe8c7f415c716b", null ],
    [ "getUint32", "class_k_paquet.html#a58c77468c4cb4a9a9a42b46095a6eff3", null ],
    [ "setUint32", "class_k_paquet.html#ab504e626cab9633f8f187c41eb364aab", null ],
    [ "setBodySize", "class_k_paquet.html#a7091642fbf5138267ed2ecfd1d25d3d8", null ],
    [ "build", "class_k_paquet.html#acc1f399a4eb360a307308fcec1b6bc68", null ],
    [ "headerSize", "class_k_paquet.html#a66a20b869a26a8a492f90a166538ae21", null ],
    [ "buildHeader", "class_k_paquet.html#a106aa804eefdb59689a7a6b987fe1fc7", null ],
    [ "builBody", "class_k_paquet.html#a12aa218793d3da4fb9b60dbc256de475", null ],
    [ "_data", "class_k_paquet.html#ae64ef8bdb85a62c4c57ccc8906e0eb76", null ]
];