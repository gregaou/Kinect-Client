var class_sound_source_angle_changed_event_args =
[
    [ "SoundSourceAngleChangedEventArgs", "class_sound_source_angle_changed_event_args.html#a2587badd39682d007d22ea97b177232e", null ],
    [ "getAngle", "class_sound_source_angle_changed_event_args.html#a60bacecce43950a62c74b68a59863dbb", null ],
    [ "getConfidenceLevel", "class_sound_source_angle_changed_event_args.html#ae3a276ed68991195039baffcdcae685e", null ],
    [ "setConfidenceLevel", "class_sound_source_angle_changed_event_args.html#a439eeca6616e6c5a2ab8085d29cf9dae", null ],
    [ "_angle", "class_sound_source_angle_changed_event_args.html#ae9ab98945c5d8203fbeffe11ec22ed25", null ],
    [ "_confidenceLevel", "class_sound_source_angle_changed_event_args.html#a4c8b3051f99b96d168aaec69b7275389", null ]
];