var class_k_kinect_sensor_collection_status_changed_action =
[
    [ "KKinectSensorCollectionStatusChangedAction", "class_k_kinect_sensor_collection_status_changed_action.html#a99ea343068f4eb9386d02e2fc3c791f6", null ],
    [ "exec", "class_k_kinect_sensor_collection_status_changed_action.html#a444c7fa689afd718295ba0d1291dd251", null ],
    [ "_paquet", "class_k_kinect_sensor_collection_status_changed_action.html#a06f48e8acdc17b2b99b998bab2961823", null ]
];