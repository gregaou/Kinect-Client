var kinect_status_8h =
[
    [ "KinectStatus", "kinect_status_8h.html#a485fe7473bcf235f8c51dda0754afd9f", null ]
];