var class_k_kinect_audio_source_beam_angle_changed_action =
[
    [ "KKinectAudioSourceBeamAngleChangedAction", "class_k_kinect_audio_source_beam_angle_changed_action.html#ac98dd2b7d9757a107292eeced14cfc44", null ],
    [ "exec", "class_k_kinect_audio_source_beam_angle_changed_action.html#a043d3b17690e8da2e539c6d30eec5789", null ],
    [ "_paquet", "class_k_kinect_audio_source_beam_angle_changed_action.html#a56833a7f8907022942308db183e88705", null ],
    [ "_sensors", "class_k_kinect_audio_source_beam_angle_changed_action.html#a6b17cea755114f7beebc2addb48bbb85", null ]
];