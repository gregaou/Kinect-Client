var libkinect_8h =
[
    [ "libKinect_init", "libkinect_8h.html#a6ccc89ae2574c61d60cd3a82e8f71a85", null ],
    [ "libKinect_quit", "libkinect_8h.html#afdc9bf3fca0acf8f23e1554efb607458", null ]
];