var class_image_frame =
[
    [ "ImageFrame", "class_image_frame.html#a472362c4169efca020d9332902956cdc", null ],
    [ "getBytesPerPixel", "class_image_frame.html#a83b3e325a361b7202916cb302463920f", null ],
    [ "getPixelDataLength", "class_image_frame.html#a5ffeadffc476ed4a1529e190b06b02bf", null ],
    [ "getFrameNumber", "class_image_frame.html#ab64aeb9fd5652066cc9dfd2b14a0829d", null ],
    [ "getHeight", "class_image_frame.html#a381bd28ba7458bf83b18fd9248e4d9dc", null ],
    [ "getWidth", "class_image_frame.html#a1846b6e7d338d2512afb9454cffe9392", null ],
    [ "getTimestamp", "class_image_frame.html#aa8f22c9620e66b4d39cba04be66d8e2f", null ],
    [ "CopyPixelDataTo", "class_image_frame.html#afd8551ca13d8cec8e7b59598e43536b0", null ],
    [ "_bytesPerPixel", "class_image_frame.html#acaeca3456fee9da7ddeff7a1e370cadc", null ],
    [ "_pixelDataLength", "class_image_frame.html#a3a41f4b782ca81e3c7aa16b8dbb6ae1b", null ],
    [ "_pixelData", "class_image_frame.html#a12e5bcc914d4b8bec2ce4033e6f6bac6", null ],
    [ "_frameNumber", "class_image_frame.html#aa9918f1d10584eef2a006f73332f830e", null ],
    [ "_width", "class_image_frame.html#a8a5b5f25898bb936b268038a39d9332f", null ],
    [ "_height", "class_image_frame.html#a30545ae9600db2213cc64c0a0f4b4f6d", null ],
    [ "_timestamp", "class_image_frame.html#ad17c87c057746a80e7c172b88cb8a582", null ]
];