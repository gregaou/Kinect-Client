var class_skeleton_stream =
[
    [ "SkeletonStream", "class_skeleton_stream.html#a2686e692f6cdee9db86fda04fbc84a60", null ],
    [ "getAppChoosesSkeletons", "class_skeleton_stream.html#af0cb428efdfe65ab51c539352b019f1a", null ],
    [ "setAppChoosesSkeletons", "class_skeleton_stream.html#a4152adc04d86656ff5d2ed8440045778", null ],
    [ "getEnableTrackingInNearRange", "class_skeleton_stream.html#a9c9c7f50cc87a923a28974797e0c21eb", null ],
    [ "setEnableTrackingInNearRange", "class_skeleton_stream.html#a1837078cfed89afe3e5a9c64ac773646", null ],
    [ "getFrameSkeletonArrayLength", "class_skeleton_stream.html#a138912e8e8de6c127c47418c1a999f9f", null ],
    [ "isEnabled", "class_skeleton_stream.html#af93d51f792d8f624aa297cffd52fc3bd", null ],
    [ "isSmoothingEnabled", "class_skeleton_stream.html#a6dd909b0e543827e24fc5a8b5d808c0f", null ],
    [ "getSmoothParameters", "class_skeleton_stream.html#a2e98eaad17a8a15275209a512d13535f", null ],
    [ "getTrackingMode", "class_skeleton_stream.html#a263083a65b5e0d7534050ff63ae12af8", null ],
    [ "setTrackingMode", "class_skeleton_stream.html#a236384a51ff63af213e3d719218bbaa6", null ],
    [ "enable", "class_skeleton_stream.html#a9dac265d95a15609ae695dfbbecc0916", null ]
];