var class_color_image_frame =
[
    [ "ColorImageFrame", "class_color_image_frame.html#a929a2ce400f9f59d56504974446502eb", null ],
    [ "getFormat", "class_color_image_frame.html#ae68b77266e5a2de4b72fb55adc2bbdf4", null ],
    [ "_format", "class_color_image_frame.html#ac166c3b53eddf3887d9e890ce2e0cbd7", null ]
];