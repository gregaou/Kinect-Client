var class_k_kinect_sensor_color_frame_ready_action =
[
    [ "KKinectSensorColorFrameReadyAction", "class_k_kinect_sensor_color_frame_ready_action.html#ac6e774227726d036e1eed8df918d8f57", null ],
    [ "exec", "class_k_kinect_sensor_color_frame_ready_action.html#a0b81caea7150ff0acc2949d4880421fe", null ],
    [ "_paquet", "class_k_kinect_sensor_color_frame_ready_action.html#a3bedae348bb1bc491f999f2b8e39db5f", null ],
    [ "_sensors", "class_k_kinect_sensor_color_frame_ready_action.html#a31b1d19a7b971a9383276a9158ebb2b0", null ]
];