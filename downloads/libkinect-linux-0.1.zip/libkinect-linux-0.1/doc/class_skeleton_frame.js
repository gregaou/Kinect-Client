var class_skeleton_frame =
[
    [ "SkeletonFrame", "class_skeleton_frame.html#adb5886beefbb1eef0277e9932bfed714", null ],
    [ "SkeletonFrame", "class_skeleton_frame.html#a1ad4979b38d63f40e7ce495338e94033", null ],
    [ "unserialize", "class_skeleton_frame.html#a18637df3bb19e132f971067bf8db2fc1", null ],
    [ "serializedSize", "class_skeleton_frame.html#a2e18b26249bdd0991c8f7a43c3fe22d6", null ],
    [ "getFloorClipPlane", "class_skeleton_frame.html#a1945b555d0d3ed49264dc075f911443a", null ],
    [ "setFloorClipPlane", "class_skeleton_frame.html#a149efe9c98cdee9de53c36bdfa70d1e3", null ],
    [ "getFrameNumber", "class_skeleton_frame.html#a798377f52f7576f61531c0a7056bfd50", null ],
    [ "setFrameNumber", "class_skeleton_frame.html#a32a7c688aefd9009c08541ff8df48b41", null ],
    [ "getSkeletonArrayLength", "class_skeleton_frame.html#a06b456ec4de73f9c2363bdb64eeb928f", null ],
    [ "getTimestamp", "class_skeleton_frame.html#a3a4cde1c8941896f79ae95811286e051", null ],
    [ "setTimestamp", "class_skeleton_frame.html#a9b11c3e80c796a18ef82df52d770441a", null ],
    [ "getTrackingMode", "class_skeleton_frame.html#a65b55ef3e1cdf7d9b0ac0c85bd2f8b01", null ],
    [ "CopySkeletonDataTo", "class_skeleton_frame.html#aef5306389602cbf6eceb77dd8425c1ab", null ],
    [ "_floorClipPlane", "class_skeleton_frame.html#a77b60a1b2f4a230fcde1ea443141645d", null ],
    [ "_frameNumber", "class_skeleton_frame.html#a62aa790abcdda371e1f45c79eef585d3", null ],
    [ "_skeletonArrayLength", "class_skeleton_frame.html#a1fa69e7e6b6ac48d82b0d00376d9390e", null ],
    [ "_timestamp", "class_skeleton_frame.html#a99a77ec0df36a753ece8e4ca33b85d5f", null ],
    [ "_trackingMode", "class_skeleton_frame.html#a488501b2ed943a913306541bf00705fa", null ],
    [ "_skeletonData", "class_skeleton_frame.html#aaeb4265b673927aeea18eb0d97368362", null ]
];