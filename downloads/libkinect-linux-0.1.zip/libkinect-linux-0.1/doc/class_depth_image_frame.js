var class_depth_image_frame =
[
    [ "DepthImageFrame", "class_depth_image_frame.html#aa27dfb16b9401098aaee2c275536e95b", null ],
    [ "getPlayerIndexBitmask", "class_depth_image_frame.html#af7db8c69e8d08b62b8a7549a5dbf4e50", null ],
    [ "getPlayerIndexBitmaskWidth", "class_depth_image_frame.html#a0fe301e09e741b7a64b4563e2a7cec68", null ],
    [ "getFormat", "class_depth_image_frame.html#a313e3b5b1eeb6a6b6aa829e081b8cde6", null ],
    [ "MapFromSkeletonPoint", "class_depth_image_frame.html#a11f56bc4dcbd12226b48b4c60fb8e79a", null ],
    [ "MapToColorImagePoint", "class_depth_image_frame.html#a2dd6ed5a1729adec7ac9296189dbb339", null ],
    [ "MapToSkeletonPoint", "class_depth_image_frame.html#a5437ee92580b35f951d467a3efacd3b7", null ],
    [ "_format", "class_depth_image_frame.html#aa47b96790a57d9550dac8100b1f0a58a", null ],
    [ "_playerIndexBitmask", "class_depth_image_frame.html#ad61b5543f59fecce7d2a8756d6da0cdd", null ],
    [ "_playerIndexBitmaskWidth", "class_depth_image_frame.html#a724b6fd3579b05a8774fc33f3eaef041", null ]
];