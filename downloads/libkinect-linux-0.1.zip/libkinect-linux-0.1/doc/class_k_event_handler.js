var class_k_event_handler =
[
    [ "KEventHandler", "class_k_event_handler.html#a01e1477d2ec64a3c708da0a1582f61fa", null ],
    [ "operator=", "class_k_event_handler.html#ad56cb35c45f9962e3c4cc8126dcf5abf", null ],
    [ "operator()", "class_k_event_handler.html#ab9b50c8a0052fa4d81a8d0ab37aac322", null ],
    [ "operator!", "class_k_event_handler.html#afa349642138e78a7ecaa78a8c379adf0", null ],
    [ "_handler", "class_k_event_handler.html#adb24fb250f8f42474f9e7c51f87a856f", null ]
];