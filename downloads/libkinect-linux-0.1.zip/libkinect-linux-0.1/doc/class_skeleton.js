var class_skeleton =
[
    [ "Skeleton", "class_skeleton.html#af01a02f1ce9ae4c801cd6e66ccf7407f", null ],
    [ "Skeleton", "class_skeleton.html#a4639e5b560a45da3f4c4ca73759499fa", null ],
    [ "unserialize", "class_skeleton.html#ad10e65d85c37eb3c830434646f742ae7", null ],
    [ "serializedSize", "class_skeleton.html#ad4bb11a516745de77c61b917bd4b49da", null ],
    [ "getBoneOrientations", "class_skeleton.html#a700f66248954f988296f5a55754ae014", null ],
    [ "getClippedEdges", "class_skeleton.html#a5bd06b73dd54b7dfb136b385461c671a", null ],
    [ "setClippedEdges", "class_skeleton.html#a5ed1d23671bf355818bd3628b2105fec", null ],
    [ "getJoints", "class_skeleton.html#a09de0e2d82ad94a62af0373fff583d64", null ],
    [ "setJoints", "class_skeleton.html#a0aa2f000e4a4ebc72eb1b8035e895641", null ],
    [ "getPosition", "class_skeleton.html#ac6d578c69c73d547bef051042a7ce75c", null ],
    [ "setPosition", "class_skeleton.html#afc11765a6cb9bed99e3a6a8aae81ea53", null ],
    [ "getTrackingId", "class_skeleton.html#af8910df6f4246e71aa239571ac4cbce1", null ],
    [ "setTrackingId", "class_skeleton.html#aa013cfc71fdbb441a1ff228ec287cb12", null ],
    [ "getTrackingState", "class_skeleton.html#a6f2302e9a82950bc472a59f14d2cd928", null ],
    [ "setTrackingState", "class_skeleton.html#a7d36116cb6cf9d9bd6a96e3cae1fc52f", null ],
    [ "_boneOrientations", "class_skeleton.html#aeeea9998fa10003090cc88ec91cd85f8", null ],
    [ "_clippedEdges", "class_skeleton.html#aa88d9cee9b52b172d81f835678029e32", null ],
    [ "_joints", "class_skeleton.html#abfb1e6192dc70124da6c01f0f416abfa", null ],
    [ "_position", "class_skeleton.html#ad91e08c860503fe0462877be22088a99", null ],
    [ "_trackingId", "class_skeleton.html#ac24659997988fa6fbc370868cee05d9d", null ],
    [ "_trackingState", "class_skeleton.html#a30d5b512eaf0ecd8e1fc12c06ab19f45", null ]
];