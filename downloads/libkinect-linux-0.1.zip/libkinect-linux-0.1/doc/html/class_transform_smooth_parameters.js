var class_transform_smooth_parameters =
[
    [ "TransformSmoothParameters", "class_transform_smooth_parameters.html#a5a192c6aa0046d4fbea5e21de349b207", null ],
    [ "getCorrection", "class_transform_smooth_parameters.html#a36e1de6cd8721a865cec97a99ed517a8", null ],
    [ "setCorrection", "class_transform_smooth_parameters.html#a07ffe8a2ce2480325bd32fccd70b39d5", null ],
    [ "getJitterRadius", "class_transform_smooth_parameters.html#afa9cdd6cd3458866e100c43c4b6b52c9", null ],
    [ "setJitterRadius", "class_transform_smooth_parameters.html#ae4b56a20bbf3aacd9115896fd51769f3", null ],
    [ "getMaxDeviationRadius", "class_transform_smooth_parameters.html#a6b09f5bd048295602203c150850adf10", null ],
    [ "setMaxDeviationRadius", "class_transform_smooth_parameters.html#af60738964718dfef02ece5348e14c643", null ],
    [ "getPrediction", "class_transform_smooth_parameters.html#aa2b0ade446dbda673507143b62441d95", null ],
    [ "setPrediction", "class_transform_smooth_parameters.html#a0c919ee5d408b03b6e74e182d8a0fe07", null ],
    [ "getSmoothing", "class_transform_smooth_parameters.html#a024d8cbaea387ac5e2b362bda987492e", null ],
    [ "setSmoothing", "class_transform_smooth_parameters.html#a9ea3bcff656194ee00acd6c9732dbfaa", null ],
    [ "equals", "class_transform_smooth_parameters.html#a112f925100c3eec2fd3104edbe84c3d4", null ],
    [ "_correction", "class_transform_smooth_parameters.html#af589ecdb556314498277d7ebca08896e", null ],
    [ "_jitterRadius", "class_transform_smooth_parameters.html#a06fdedcf5b372981d7ecb7f576c5ba6c", null ],
    [ "_maxDeviationRadius", "class_transform_smooth_parameters.html#a760e2104eaec1b2de7e1d9933f37c12b", null ],
    [ "_prediction", "class_transform_smooth_parameters.html#acaab73a53b309abbaa56096b1ab786de", null ],
    [ "_smoothing", "class_transform_smooth_parameters.html#a3ad80688fda06b7cb4dcbf9e52f1d2e7", null ]
];