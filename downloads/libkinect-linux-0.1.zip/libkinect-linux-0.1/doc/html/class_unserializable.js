var class_unserializable =
[
    [ "~Unserializable", "class_unserializable.html#a3717fcb6dc6acb075b496842c480a782", null ],
    [ "unserialize", "class_unserializable.html#af479e4af9aee8ecdf8cc1c2ef05481a6", null ],
    [ "serializedSize", "class_unserializable.html#a7a82dceca228e60f619e5f7af5cb695c", null ]
];