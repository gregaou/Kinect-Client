var class_depth_image_stream =
[
    [ "DepthImageStream", "class_depth_image_stream.html#a04ae566becca56527c515856c74c05bc", null ],
    [ "getFormat", "class_depth_image_stream.html#a82f63d7a6d61abdc40db23cb75d49c39", null ],
    [ "getMaxDepth", "class_depth_image_stream.html#a591b2e42378d4d3cfcb7e2a9ab19b1c8", null ],
    [ "getMinDepth", "class_depth_image_stream.html#af0554c3800d5dc23899af74849411660", null ],
    [ "getNominalDiagonalFieldOfView", "class_depth_image_stream.html#a44f10f96cec4e10b78d0d4a7941ef423", null ],
    [ "getNominalFocalLengthInPixels", "class_depth_image_stream.html#a6aab7cdaddd062664996450e821c7654", null ],
    [ "getNominalHorizontalFieldOfView", "class_depth_image_stream.html#ae9311cbca331df35191d02a43637844e", null ],
    [ "getNominalInverseFocalLengthInPixels", "class_depth_image_stream.html#a2306e7c6675c7f9f10baddb7ed4967c9", null ],
    [ "getNominalVerticalFieldOfView", "class_depth_image_stream.html#a221350262048d45e55043959b458a7c7", null ],
    [ "getRange", "class_depth_image_stream.html#a63fda9a79f5522851fc7100e5092becf", null ],
    [ "setRange", "class_depth_image_stream.html#a6c3c3a3cd012676e1a0096022953f574", null ],
    [ "getTooFarDepth", "class_depth_image_stream.html#a8363318fbb6962ec4fcbf69fb14fe04b", null ],
    [ "getTooNearDepth", "class_depth_image_stream.html#aa46dc80608ecb8e6ca490ad690af7a85", null ],
    [ "getUnknownDepth", "class_depth_image_stream.html#af28291ba20fac01fdcb693961db487e9", null ],
    [ "enable", "class_depth_image_stream.html#a19ebd1c8f54cb41c85a0d923bcdc2c86", null ]
];