var class_audio_data_ready_event_args =
[
    [ "AudioDataReadyEventArgs", "class_audio_data_ready_event_args.html#ace1cddb2e13f96115abc1d3924d4ee4b", null ],
    [ "getAudioData", "class_audio_data_ready_event_args.html#acc4ce215c699c0c281e3762ebbfcac5c", null ],
    [ "_audioData", "class_audio_data_ready_event_args.html#a99598797f98113a6edbcf6cd2947c197", null ]
];