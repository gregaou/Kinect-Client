var class_color_image_frame_ready_event_args =
[
    [ "ColorImageFrameReadyEventArgs", "class_color_image_frame_ready_event_args.html#a419a9889cbdb932533d707fa2b483da6", null ],
    [ "openColorImageFrame", "class_color_image_frame_ready_event_args.html#a39fa2540610bd260f0c8a3029cae011c", null ],
    [ "_frame", "class_color_image_frame_ready_event_args.html#ac7c00ff53aeb928582cdbfa57ef445a3", null ]
];