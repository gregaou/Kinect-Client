var class_k_client_paquet =
[
    [ "KClientPaquet", "class_k_client_paquet.html#a16c2e5c70e249be0b51767eb2a17c115", null ],
    [ "send", "class_k_client_paquet.html#a8779fdcbc505ab67151af071ac57bba3", null ],
    [ "headerSize", "class_k_client_paquet.html#aee67879933f46b6fdf9f6e04865caa34", null ],
    [ "buildHeader", "class_k_client_paquet.html#ae0173336a735ed1480e05a9922f3e627", null ],
    [ "builBody", "class_k_client_paquet.html#a3425f78f0e8df81ebf5c3e503a0b8461", null ],
    [ "_headerSize", "class_k_client_paquet.html#ac97a4e33a03ea96a946fe8856f716a32", null ],
    [ "_query", "class_k_client_paquet.html#ad284975acea45c7f920b03d4a5516bb8", null ]
];