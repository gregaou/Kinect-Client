var class_k_kinect_sensor_depth_frame_ready_action =
[
    [ "KKinectSensorDepthFrameReadyAction", "class_k_kinect_sensor_depth_frame_ready_action.html#a725140d8aeb1228977fbf6fdb0d2964c", null ],
    [ "exec", "class_k_kinect_sensor_depth_frame_ready_action.html#a2a4d9981a6ac684e6b54045f04312445", null ],
    [ "_paquet", "class_k_kinect_sensor_depth_frame_ready_action.html#a4df583a649dec541ace89f9363a3de2c", null ],
    [ "_sensors", "class_k_kinect_sensor_depth_frame_ready_action.html#afde3065a25aa2e834c7886bd746831d6", null ]
];