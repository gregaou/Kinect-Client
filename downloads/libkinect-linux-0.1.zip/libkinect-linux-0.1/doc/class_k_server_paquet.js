var class_k_server_paquet =
[
    [ "KServerPaquet", "class_k_server_paquet.html#a07756ad5fcb58494e2cd7882b453cb50", null ],
    [ "id", "class_k_server_paquet.html#af04b4470f6ba755b9aa11c4ce31d4469", null ],
    [ "data", "class_k_server_paquet.html#ac0fec4ec05232f812ae14de7dc9e9057", null ],
    [ "vectorData", "class_k_server_paquet.html#ac170dbdf48dda35f0d73c93315e57541", null ],
    [ "stringData", "class_k_server_paquet.html#aba18a1cb2c7b50b03fb09a9459db8eb1", null ],
    [ "headerSize", "class_k_server_paquet.html#a0c565e8a794fc9ae976a3d9cd77876cc", null ],
    [ "buildHeader", "class_k_server_paquet.html#a708b23eca7a98d380f7e463243219ef1", null ],
    [ "builBody", "class_k_server_paquet.html#a5960e9aa031d9fd706686113e6e39bb4", null ],
    [ "_sock", "class_k_server_paquet.html#ae7792f78a2f1b9246a3fc23a8d62f533", null ],
    [ "_headerSize", "class_k_server_paquet.html#a5624a24f7de9646bf5368036b04f390f", null ]
];