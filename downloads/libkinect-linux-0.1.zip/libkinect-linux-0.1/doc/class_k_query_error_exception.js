var class_k_query_error_exception =
[
    [ "KQueryErrorException", "class_k_query_error_exception.html#aa077738c9ed48ccbf1b6195a7e84af13", null ],
    [ "~KQueryErrorException", "class_k_query_error_exception.html#a7e1f0181916ef0b44a86eba8ee0b0a87", null ],
    [ "what", "class_k_query_error_exception.html#acf0ce601c16c2e0cef7bb99548e17fa9", null ],
    [ "code", "class_k_query_error_exception.html#a2b988637b4b52b58487ea51ffea3383d", null ],
    [ "msg", "class_k_query_error_exception.html#a0dcf663135ac997d6eaa9f6afb07bb57", null ],
    [ "_code", "class_k_query_error_exception.html#ac6c6aa32a20b85a5bbcb13ad6866fa00", null ],
    [ "_msg", "class_k_query_error_exception.html#a6036ffe43e13e39f5a4b996c95d831e8", null ]
];