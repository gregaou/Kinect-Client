var frame_edges_8h =
[
    [ "RIGHT", "frame_edges_8h.html#a80fb826a684cf3f0d306b22aa100ddac", null ],
    [ "LEFT", "frame_edges_8h.html#a437ef08681e7210d6678427030446a54", null ],
    [ "TOP", "frame_edges_8h.html#afc0eef637f1016e8786e45e106a4881e", null ],
    [ "BOTTOM", "frame_edges_8h.html#ae420caa0af9cbdf102ed255034e27c5b", null ],
    [ "FrameEdges", "frame_edges_8h.html#a8d8e7a6cfaeb00386411494d5d9a23a0", null ]
];