var class_skeleton_frame_ready_event_args =
[
    [ "SkeletonFrameReadyEventArgs", "class_skeleton_frame_ready_event_args.html#a945882ce16e708a2db33106bb50c2ba2", null ],
    [ "SkeletonFrameReadyEventArgs", "class_skeleton_frame_ready_event_args.html#ae1bb2ae3caac515b6ea3c682c27c5b7f", null ],
    [ "unserialize", "class_skeleton_frame_ready_event_args.html#a55800df5a0faec8b92c1c0db1e5d9b17", null ],
    [ "serializedSize", "class_skeleton_frame_ready_event_args.html#a1788ab83f70e368b7df85d3f3d2e7634", null ],
    [ "openSkeletonFrame", "class_skeleton_frame_ready_event_args.html#aee1c27fa300a98e61b9f5433f07bdac4", null ],
    [ "_frame", "class_skeleton_frame_ready_event_args.html#a3d17dd971ed7bbd61d59726e0c5d97ff", null ]
];