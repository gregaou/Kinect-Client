var class_bone_orientation =
[
    [ "BoneOrientation", "class_bone_orientation.html#a637827e99767ec5ab3fff6f4ef1e5f87", null ],
    [ "BoneOrientation", "class_bone_orientation.html#a33af8f225ae030fef80940c733d50338", null ],
    [ "unserialize", "class_bone_orientation.html#af02305e1772d320fdca540dfec38585b", null ],
    [ "serializedSize", "class_bone_orientation.html#a6e746b11aeb32195d481f08881109f1e", null ],
    [ "getAbsoluteRotation", "class_bone_orientation.html#aceb1b795cba77956baecaaf449bb78c2", null ],
    [ "setAbsoluteRotation", "class_bone_orientation.html#a9414d91ba4107451208e972821fa210e", null ],
    [ "getEndJoint", "class_bone_orientation.html#aff03a9e6c54f92f060fb1e8ceffbab7a", null ],
    [ "getHierarchicalRotation", "class_bone_orientation.html#af17fdc4d83a1173ae94f1e609ed9e1ad", null ],
    [ "setHierarchicalRotation", "class_bone_orientation.html#afc3e6527192a8a3344f2453f20df014f", null ],
    [ "getStartJoint", "class_bone_orientation.html#ab49ca455cfcd4686df46d73a72430d15", null ],
    [ "_absoluteRotation", "class_bone_orientation.html#a2334dcc3cdd45149077cf2bb9e900760", null ],
    [ "_endJoint", "class_bone_orientation.html#a1e915ac581263b89500c2830035697dc", null ],
    [ "_hierarchicalRotation", "class_bone_orientation.html#add903a189f90b60b038da25b1c8c333d", null ],
    [ "_startJoint", "class_bone_orientation.html#ae009fb4a7b190dfbd3a4acb0421bdec7", null ]
];