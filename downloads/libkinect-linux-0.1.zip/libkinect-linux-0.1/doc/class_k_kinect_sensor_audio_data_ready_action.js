var class_k_kinect_sensor_audio_data_ready_action =
[
    [ "KKinectSensorAudioDataReadyAction", "class_k_kinect_sensor_audio_data_ready_action.html#a2b93a3b26d85c8e6e85a4a95798b847e", null ],
    [ "exec", "class_k_kinect_sensor_audio_data_ready_action.html#a30faad3a0201f1166cf41d5f719dbf5d", null ],
    [ "_paquet", "class_k_kinect_sensor_audio_data_ready_action.html#a746555a08aff9275cae3bcf93e3baecc", null ],
    [ "_sensors", "class_k_kinect_sensor_audio_data_ready_action.html#aa80295deed838048ff30e56f77a82493", null ]
];