var class_k_kinect_sensor_skeleton_frame_ready_action =
[
    [ "KKinectSensorSkeletonFrameReadyAction", "class_k_kinect_sensor_skeleton_frame_ready_action.html#adb8533590fd6b76ff30b2f0d401659e5", null ],
    [ "exec", "class_k_kinect_sensor_skeleton_frame_ready_action.html#ab384c087248d68fb6f4915bf714d5f77", null ],
    [ "_paquet", "class_k_kinect_sensor_skeleton_frame_ready_action.html#ad895cba2697181d2adad288068ee0ca5", null ],
    [ "_sensors", "class_k_kinect_sensor_skeleton_frame_ready_action.html#a557320ad0ab75ec3a5ff70b7b873c486", null ]
];