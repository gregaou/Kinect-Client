var class_depth_image_frame_ready_event_args =
[
    [ "DepthImageFrameReadyEventArgs", "class_depth_image_frame_ready_event_args.html#a0f54c219ce8d996b37bd2b5beedcae09", null ],
    [ "openDepthImageFrame", "class_depth_image_frame_ready_event_args.html#a637316dcf0710591053a4045a16b0c23", null ],
    [ "_frame", "class_depth_image_frame_ready_event_args.html#af93df04c79d08168c85483e5982714d5", null ]
];