var class_k_connection_exception =
[
    [ "KConnectionException", "class_k_connection_exception.html#a9be036e73c0b0c0d44189b0394e3172a", null ]
];